/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


public class Authentication {
    
    public static boolean authentication(String username,String password){
        if(username.equals("Milton") && password.equals("contra123")){
            return true;
        }
        else{
            return false;
        }
    }
}
