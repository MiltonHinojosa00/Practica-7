/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


public class User {
    private String Nombre;
    private String Apellidos;
        private String password;
            private String username;

    
    public User (String password,String username){
        this.username=username;
        this.password=password;
        this.Nombre="Milton";
        this.Apellidos="Hinojosa";
        
    }

    public String getNombre() {
        return Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
   
}
